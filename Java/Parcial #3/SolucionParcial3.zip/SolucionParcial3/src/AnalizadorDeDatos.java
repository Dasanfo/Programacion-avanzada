import java.util.ArrayList;
public class AnalizadorDeDatos {
    // ATRIBUTOS
    ArrayList<ConjutoDeDatos> conjutoDeDatos;
    // CONSTRUCTOR
    public AnalizadorDeDatos(ArrayList<ConjutoDeDatos> conjutoDeDatos) {
        this.conjutoDeDatos = conjutoDeDatos;
    }
    // GETTERS Y SETTERS
    public ArrayList<ConjutoDeDatos> getConjutoDeDatos() {
        return conjutoDeDatos;
    }
    public void setConjutoDeDatos(ArrayList<ConjutoDeDatos> conjutoDeDatos) {
        this.conjutoDeDatos = conjutoDeDatos;
    }
    //METODOS
    public void agregarConjuntoDeDatos (ConjutoDeDatos conjunto1){ // AGREFO UN CONJUNTO DADO COMO PARAMETRO A LA LISTA DE CONJUNTOS
        conjutoDeDatos.add(conjunto1);
    }
    public void eliminarConjuntoDeDatos (String nombre){ // ELIMINO UN CONJUTNO DADO SU NOMBRE
        boolean eliminado = false; // VARIABLE QUE ME AYUDA A SABER SI EL CONJUNTO FUE ENCONTRADO
        ConjutoDeDatos conjuntoAux = new ConjuntoDeDatosImagen("",0,0,0); // OBJETO QUE ME AYUDARA A ELIMINAR MI CONJUNTO
        for (ConjutoDeDatos c1: conjutoDeDatos){ // BUSCO AL CONJUNTO POR SU NOMBRE EN LA LISTAA DE CONJUNTOS
            if (c1.getNombre().equals(nombre)){
                eliminado = true; // SI LO ENCUENTRO MI VARIABLE ES TRUE
                conjuntoAux = c1;// GUARDO EL CONJUNOT EN MI OBJETO TIPO CONJUNTO
            }
        }
        if (eliminado){ // SI MI VARIABLE ES TRU OSEA SI ENCONTRE EL CONJUNTO POR SU NOMBRE LO ELIMINO
            conjutoDeDatos.remove(conjuntoAux); // ELIMINO EL CONJUNTO
            System.out.println("Se elimino correctamente el conjunto de datos: " +conjuntoAux.getNombre());
        }
        System.out.println("---------------------------------------------------------------------------------------------------------------");
    }

    public ArrayList<String> describirConjuntosDeDatos(){
        ArrayList<String> conjutoDescribir = new ArrayList<>(); // ARRAY LIST DEL METODO ABSTRACTO DESCRIBIR POR ENDE EL ARRAAY ES DE TIPO STRING
        for (ConjutoDeDatos c1: conjutoDeDatos) { // RECORRO MI LISTA
            conjutoDescribir.add(c1.describir()); // LLAMO A CADA CONJUNTO DE LA LISTA E INVOCO EL METODO PARA ASI POODER GUARDALO EN EL ARRAYLIST
        }
        return conjutoDescribir; // RETORNO EL ARRAY
    }


}
