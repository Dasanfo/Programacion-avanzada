public abstract class ConjutoDeDatos {
    // ATRIBUTOS
    private String nombre;
    private int tamano;
    // CONSTRUCTOR
    public ConjutoDeDatos(String nombre, int tamano) {
        this.nombre = nombre;
        this.tamano = tamano;
    }
    // GETTERS Y SETTERS
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getTamano() {
        return tamano;
    }
    public void setTamano(int tamano) {
        this.tamano = tamano;
    }
    //METODO ABSTRACTO
    public abstract String describir();
}
