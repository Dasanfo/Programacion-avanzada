public class ConjuntoDeDatosImagen extends ConjutoDeDatos{
    // ATRIBUTOS
    private int ancho;
    private int alto;
    // CONSTRUCTOR
    public ConjuntoDeDatosImagen(String nombre, int tamano, int ancho, int alto) {
        super(nombre, tamano);
        this.ancho = ancho;
        this.alto = alto;
    }
    // GETTERS Y SETTERS
    public int getAncho() {
        return ancho;
    }
    public void setAncho(int ancho) {
        this.ancho = ancho;
    }
    public int getAlto() {
        return alto;
    }
    public void setAlto(int alto) {
        this.alto = alto;
    }
    // SOBREESCRIBO EL METODO ABSTACTO DESCRIBIR
    @Override
    public String describir(){// RETORNO TODOS LOS ATRIBUTOS DE ESTA CLASE
        return "\nNombre: "+getNombre()+ " \nTamaño: "+getTamano()+ "\nTipo: Imagen \nAncho: " +getAncho()+ " \nAlto: "+ getAlto()+"\n---------------------------------------------------------------------------------------------------------------";
    }

}
