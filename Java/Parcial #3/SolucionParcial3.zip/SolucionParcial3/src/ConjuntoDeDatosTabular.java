public class ConjuntoDeDatosTabular extends ConjutoDeDatos{
    // ATRIBUTOS
    private int numeroDeColumnas;
    private int numeroDeFIlas;
    // CONSTRUCTOR
    public ConjuntoDeDatosTabular(String nombre, int tamano, int numeroDeFIlas, int  numeroDeColumnas) {
        super(nombre, tamano);
        this.numeroDeFIlas = numeroDeFIlas;
        this.numeroDeColumnas = numeroDeColumnas;
    }
    // GETTERS Y SETTERS
    public int getNumeroDeColumnas() {
        return numeroDeColumnas;
    }

    public void setNumeroDeColumnas(int numeroDeColumnas) {
        this.numeroDeColumnas = numeroDeColumnas;
    }

    public int getNumeroDeFIlas() {
        return numeroDeFIlas;
    }

    public void setNumeroDeFIlas(int numeroDeFIlas) {
        this.numeroDeFIlas = numeroDeFIlas;
    }
    // SOBREESCRIBO EL METODO ABSTACTO DESCRIBIR
    @Override
    public String describir(){ // RETORNO TODOS LOS ATRIBUTOS DE ESTA CLASE
        return "\nNombre: "+getNombre()+ " \nTamaño: "+getTamano()+ " \nTipo: tabular \nFilas: " +getNumeroDeFIlas()+ " \nColumnas: "+ getNumeroDeColumnas()+"\n---------------------------------------------------------------------------------------------------------------";
    }
}
