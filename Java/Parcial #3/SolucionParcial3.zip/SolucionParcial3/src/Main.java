/* Solución preguntas del parcial
* 1 -> V
* 2 -> V
* 3 -> F
* 4 -> V
* 5 -> V
* 6 -> D. la capacidad de un objeto de ser tratado como uno de varios tipos posibles.
* 7 -> D. la capacidad de un objeto de ser tratado como uno de varios tipos posibles.
* 8 -> D. se utilizan como plantillas para crear subclases concretas.
* 9 -> A. la capacidad de una subclase de proporcionar una implementación diferente para un método heredado de la clase padre.
* 10 -> D. Una clase puede implementar múltiples interfaces al mismo tiempo.
*/
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // CREO ALGUNOS CONJUNTOS
        ConjuntoDeDatosTabular conjunto00 = new ConjuntoDeDatosTabular("Datos de estudiantes",1000,200,5);
        ConjuntoDeDatosImagen conjunto01 =  new ConjuntoDeDatosImagen("Imagenes de satelite",2000,1080,720);
        ConjuntoDeDatosImagen conjunto02 = new ConjuntoDeDatosImagen("Imagenes de satelite",2000,1080,720);
        ConjuntoDeDatosTabular conjunto03 = new ConjuntoDeDatosTabular("Datos de animales",1500,200,10);
        ArrayList <ConjutoDeDatos> conjuntos = new ArrayList<>();
        AnalizadorDeDatos analizadorDeDatos = new AnalizadorDeDatos(conjuntos); // CREO UN OBJETO PARA LLAMAR SUS METODOS
        // AÑADO LOS CONJUTNOS A LA LISTA DE CONJUNTOS
        conjuntos.add(conjunto00);
        conjuntos.add(conjunto01);
        conjuntos.add(conjunto02);
        System.out.println("LISTA INICIAL:");
        System.out.println("---------------------------------------------------------------------------------------------------------------");
        for (ConjutoDeDatos c1: conjuntos){// MUESTRO EN PANTALLA EL CONJUTNO USANDO EL METODO ABSTRACTO DESCRIBIR
            System.out.println(c1.describir());
        }
        analizadorDeDatos.agregarConjuntoDeDatos(conjunto03);// AÑADO UN CONJUNTO CON EL METODO AGREGARCONJUTNO
        System.out.println("LISTA DESPUES DE AGREGAR UN CONJUNTO:");
        System.out.println("---------------------------------------------------------------------------------------------------------------");
        for (ConjutoDeDatos c1: conjuntos){ // MUESTRO EN PANTALLA EL CONJUTNO USANDO EL METODO ABSTRACTO DESCRIBIR
            System.out.println(c1.describir());
        }
        analizadorDeDatos.eliminarConjuntoDeDatos("Datos de animales"); // ELIMINO UN CONJUNTO CON EL METODO ELIMINAR DE LA CLASE ANALISAR

        System.out.println("LISTA DESPUES DE ELIMINAR UN CONJUNTO:");
        System.out.println("---------------------------------------------------------------------------------------------------------------");
        System.out.println(analizadorDeDatos.describirConjuntosDeDatos()); // MUESTRO EN PANTALLA LOS CONJUTNOS CON EL METODO QUE ME DEVUELVE EL ARRAY DE STRING


    }
}

