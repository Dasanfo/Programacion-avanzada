class Validador{
    public Validador(){
    };

    public void validarModelo(Modelo m1){
        m1.entrenar();
        if (m1 instanceof ModeloLineal){
            ModeloLineal mAux = (ModeloLineal) m1;
            if (mAux.getCoeficienteCorrelacion() > 0.8 && mAux.getErrorCuadraticoMedio()<0.2){
                System.out.println("El modelo: "+mAux.getNombre()+ " ha pasado la validación.");
            }else{
                System.out.println("El modelo: "+mAux.getNombre()+" no ha pasado la validacion");
            }
        } else if(m1 instanceof ModeloArbolDecision){
            ModeloArbolDecision mAux2 = (ModeloArbolDecision) m1;
            if (mAux2.getProfundidaArbol() < 10 && mAux2.getCantidadNodos() > 5){
                System.out.println("El modelo: "+mAux2.getNombre()+ " ha pasado la validación.");
            }else{
                System.out.println("El modelo: "+mAux2.getNombre()+" no ha pasado la validacion");
            }
        }
    }
}