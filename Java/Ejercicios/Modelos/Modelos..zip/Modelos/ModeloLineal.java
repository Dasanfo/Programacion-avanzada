public class ModeloLineal extends Modelo{

    private double coeficienteCorrelacion;
    private double errorCuadraticoMedio;


    public ModeloLineal(String nombre, int numeroParametros, double coeficienteCorrelacion, double errorCuadraticoMedio){
        super(nombre,numeroParametros);
        this.coeficienteCorrelacion = coeficienteCorrelacion;
        this.errorCuadraticoMedio = errorCuadraticoMedio;
    }

    public double getCoeficienteCorrelacion() {
        return coeficienteCorrelacion;
    }

    public void setCoeficienteCorrelacion(double coeficienteCorrelacion) {
        this.coeficienteCorrelacion = coeficienteCorrelacion;
    }

    public double getErrorCuadraticoMedio() {
        return errorCuadraticoMedio;
    }

    public void setErrorCuadraticoMedio(double errorCuadraticoMedio) {
        this.errorCuadraticoMedio = errorCuadraticoMedio;
    }

    @Override
    public void entrenar(){
        System.out.println("\nEntrenando modelo lineal: " + getNombre());
        System.out.println("Número de parámetros: " + getNumeroParametros());
        System.out.println("Coeficiente de correlación inicial: " + getCoeficienteCorrelacion());
        System.out.println("Error cuadrático medio inicial: " + getErrorCuadraticoMedio()+"\nEntrenamiento completado.");
    }
}