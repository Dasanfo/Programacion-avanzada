public class ModeloArbolDecision extends Modelo{

    private int profundidaArbol;
    private int cantidadNodos;

    public ModeloArbolDecision(String nombre, int numeroParametros, int profundidaArbol, int cantidadNodos){
        super(nombre,numeroParametros);
        this.profundidaArbol = profundidaArbol;
        this.cantidadNodos = cantidadNodos;
    }

    public int getProfundidaArbol() {
        return profundidaArbol;
    }

    public void setProfundidaArbol(int profundidaArbol) {
        this.profundidaArbol = profundidaArbol;
    }

    public int getCantidadNodos() {
        return cantidadNodos;
    }

    public void setCantidadNodos(int cantidadNodos) {
        this.cantidadNodos = cantidadNodos;
    }

    @Override
    public void entrenar(){
        System.out.println("\nEntrenando modelo de arbol de decision:" +getNombre());
        System.out.println("Numero de parámetros:"+getNumeroParametros());
        System.out.println("Profundidad del arbol:" +getProfundidaArbol());
        System.out.println("Numero de nodos hoja:" +getCantidadNodos()+"\nEntrenamiento completado.");
    };
}