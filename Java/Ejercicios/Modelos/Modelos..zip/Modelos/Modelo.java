abstract class Modelo{

    private String nombre;
    private int numeroParametros;

    public Modelo(String nombre, int numeroParametros){
        this.nombre = nombre;
        this.numeroParametros = numeroParametros;
    };

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumeroParametros() {
        return numeroParametros;
    }

    public void setNumeroParametros(int numeroParametros) {
        this.numeroParametros = numeroParametros;
    }

    public abstract void entrenar();

}