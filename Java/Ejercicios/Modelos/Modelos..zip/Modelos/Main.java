import java.util.ArrayList;

class Main {
    public static void main(String[] args) {
        ArrayList<Modelo> modelos = new ArrayList<>();
        Validador v1 = new Validador();
        ModeloLineal modeloLineal = new ModeloLineal("FORK",5,0.2,0.5);
        ModeloArbolDecision modeloArbolDecision = new ModeloArbolDecision("CHAID",3,10,2);

        modelos.add(modeloLineal);
        modelos.add(modeloArbolDecision);

        for (Modelo modelo : modelos) {
            v1.validarModelo(modelo);
        }
    }
}