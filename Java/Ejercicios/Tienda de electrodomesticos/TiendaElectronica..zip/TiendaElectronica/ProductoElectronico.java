abstract class ProductoElectronico {
    private String nombre;
    private double precio;
    private int garantia;

    // Constructor de la clase
    public ProductoElectronico(String nombre, double precio, int garantia) {
        this.nombre = nombre;
        this.precio = precio;
        this.garantia = garantia;
    }

    // Método getter para obtener el nombre del producto
    public String getNombre() {
        return nombre;
    }

    // Método getter para obtener el precio del producto
    public double getPrecio() {
        return precio;
    }

    // Método getter para obtener la garantía del producto
    public int getGarantia() {
        return garantia;
    }

    // Método abstracto que debe ser implementado por las clases hijas
    public abstract void cargar(int cargaInicial);

    // Método para mostrar la información básica del producto
    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Precio: " + precio);
        System.out.println("Garantía: " + garantia + " meses");
    }
}
