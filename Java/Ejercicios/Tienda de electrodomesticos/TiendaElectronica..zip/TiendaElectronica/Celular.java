// Clase hija que representa un celular
class Celular extends ProductoElectronico {
    private String modelo;
    private int capacidadBateria;
    private int velocidadCarga;

    // Constructor de la clase
    public Celular(String nombre, double precio, int garantia, String modelo, int capacidadBateria, int velocidadCarga) {
        super(nombre, precio, garantia);
        this.modelo = modelo;
        this.capacidadBateria = capacidadBateria;
        this.velocidadCarga = velocidadCarga;
    }

    // Implementación del método abstracto de la clase base
    @Override
    public void cargar(int cargaInicial) {
        double tiempoCarga = (capacidadBateria - cargaInicial) / velocidadCarga;
        System.out.println("Cargando el celular " + modelo + " con una carga inicial de " + cargaInicial + " horas.");
        System.out.println("Tiempo estimado de carga: " + tiempoCarga + " horas.");
    }

    // Método adicional que simula hacer una llamada desde el celular
    public void hacerLlamada(String numero) {
        System.out.println("Llamando al número " + numero + " desde el celular " + modelo + ".");
    }
}