import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

// Clase principal que contiene el programa principal
public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static List<ProductoElectronico> productos = new ArrayList<>();

    public static void main(String[] args) {
        int opcion;

        do {
            mostrarMenu();
            opcion = obtenerOpcion();

            switch (opcion) {
                case 1:
                    crearCelular();
                    break;
                case 2:
                    crearComputadora();
                    break;
                case 3:
                    mostrarInformacionProductos();
                    break;
                case 4:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, ingrese una opción válida.");
                    break;
            }

            System.out.println();
        } while (opcion != 4);

        scanner.close();
    }

    // Método que muestra el menú de opciones
    private static void mostrarMenu() {
        System.out.println("----- MENÚ -----");
        System.out.println("1. Crear Celular");
        System.out.println("2. Crear Computadora");
        System.out.println("3. Mostrar información de los productos");
        System.out.println("4. Salir");
        System.out.print("Ingrese una opción: ");
    }

    // Método que obtiene la opción seleccionada por el usuario
    private static int obtenerOpcion() {
        int opcion;
        while (true) {
            try {
                opcion = scanner.nextInt();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número válido.");
                scanner.next(); // Limpiar el búfer del escáner
            }
        }
        return opcion;
    }

    // Método que permite crear un nuevo celular
    private static void crearCelular() {
        System.out.print("Ingrese el nombre del celular: ");
        String nombreCelular = scanner.next();
        System.out.print("Ingrese el precio del celular: ");
        double precioCelular = scanner.nextDouble();
        System.out.print("Ingrese la garantía del celular (meses): ");
        int garantiaCelular = scanner.nextInt();
        System.out.print("Ingrese el modelo del celular: ");
        String modeloCelular = scanner.next();
        System.out.print("Ingrese la capacidad de la batería del celular (mAh): ");
        int capacidadBateriaCelular = scanner.nextInt();
        System.out.print("Ingrese la velocidad de carga del celular (mAh/h): ");
        int velocidadCargaCelular = scanner.nextInt();

        Celular celular = new Celular(nombreCelular, precioCelular, garantiaCelular, modeloCelular,
                capacidadBateriaCelular, velocidadCargaCelular);
        productos.add(celular);
        System.out.println("Celular creado con éxito.");
    }

    // Método que permite crear una nueva computadora
    private static void crearComputadora() {
        System.out.print("Ingrese el nombre de la computadora: ");
        String nombreComputadora = scanner.next();
        System.out.print("Ingrese el precio de la computadora: ");
        double precioComputadora = scanner.nextDouble();
        System.out.print("Ingrese la garantía de la computadora (meses): ");
        int garantiaComputadora = scanner.nextInt();
        System.out.print("Ingrese la marca de la computadora: ");
        String marcaComputadora = scanner.next();
        System.out.print("Ingrese la capacidad de la batería de la computadora (mAh): ");
        int capacidadBateriaComputadora = scanner.nextInt();
        System.out.print("Ingrese la velocidad de carga de la computadora (mAh/h): ");
        int velocidadCargaComputadora = scanner.nextInt();

        Computadora computadora = new Computadora(nombreComputadora, precioComputadora, garantiaComputadora,
                marcaComputadora, capacidadBateriaComputadora, velocidadCargaComputadora);
        productos.add(computadora);
        System.out.println("Computadora creada con éxito.");
    }

    // Método que muestra la información de todos los productos
    private static void mostrarInformacionProductos() {
        if (productos.isEmpty()) {
            System.out.println("No hay productos para mostrar.");
        } else {
            System.out.println("----- PRODUCTOS -----");
            for (ProductoElectronico producto : productos) {
                producto.mostrarInformacion();
                producto.cargar(60); // Ejemplo de carga inicial de 60 minutos

                if (producto instanceof Celular) {
                    Celular celular = (Celular) producto;
                    celular.hacerLlamada("123456789");
                } else if (producto instanceof Computadora) {
                    Computadora computadora = (Computadora) producto;
                    computadora.ejecutarPrograma("Word");
                }
                System.out.println();
            }
        }
    }
}