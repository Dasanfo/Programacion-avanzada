// Clase hija que representa una computadora
class Computadora extends ProductoElectronico {
    private String marca;
    private int capacidadBateria;
    private int velocidadCarga;

    // Constructor de la clase
    public Computadora(String nombre, double precio, int garantia, String marca, int capacidadBateria, int velocidadCarga) {
        super(nombre, precio, garantia);
        this.marca = marca;
        this.capacidadBateria = capacidadBateria;
        this.velocidadCarga = velocidadCarga;
    }

    // Implementación del método abstracto de la clase base
    @Override
    public void cargar(int cargaInicial) {
        double tiempoCarga = (capacidadBateria - cargaInicial) / velocidadCarga;
        System.out.println("Cargando la computadora " + marca + " con una carga inicial de " + cargaInicial + " minutos.");
        System.out.println("Tiempo estimado de carga: " + tiempoCarga + " minutos.");
    }

    // Método adicional que simula ejecutar un programa en la computadora
    public void ejecutarPrograma(String programa) {
        System.out.println("Ejecutando el programa " + programa + " en la computadora " + marca + ".");
    }
}