import java.util.ArrayList;
import java.util.Scanner;
public class PantallaGaleria {
    public static void main(String[] args) {
        ArrayList<Artista> listaArtistas = new ArrayList<>();
        Artista artista00 = new Artista(111,"daniel","2004-02-26","Colombiano","Artista moderno");
        Artista artista01 = new Artista(222,"picaso","1954-06-20","Español","Artista conteporaneo");
        Artista artista02 = new Artista(333,"sergio","1994-08-20","Venezolano","Artista clasico");
        Artista artista03 = new Artista(444,"leonardo","1954-06-20","Italiana","Artista renacentista");
        listaArtistas.add(artista00);
        listaArtistas.add(artista01);
        listaArtistas.add(artista02);
        ArrayList<Artista> listaArtistasEliminados = new ArrayList<>();
        ArrayList<Compra> listaCompras = new ArrayList<>();
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        Cliente cliente00 = new Cliente("Santiago","Crr 95","santiago.com");
        Cliente cliente01 = new Cliente("Libia","Crr 95","Libia.com");
        listaClientes.add(cliente00);
        listaClientes.add(cliente01);
        ArrayList<Cliente> listaClientesEliminados = new ArrayList<>();
        ArrayList<Obra> listaObras = new ArrayList<>();
        Obra obra00 = new Obra("Monalisa","acuarela",1998,15.00,artista03);
        Obra obra01 = new Obra("La noche estrellada", "óleo", 1889, 20.50, artista01);
        Obra obra02 = new Obra("El grito", "temple", 1893, 18.75, artista02);
        Obra obra03 = new Obra("La persistencia de la memoria", "óleo", 1931, 22.25, artista00);
        Obra obra04 = new Obra("Guernica", "óleo", 1937, 25.00, artista02);
        Obra obra05 = new Obra("El beso", "litografía", 1907, 16.80, artista02);
        listaObras.add(obra00);
        listaObras.add(obra01);
        listaObras.add(obra02);
        listaObras.add(obra03);
        listaObras.add(obra04);
        listaObras.add(obra05);
        ArrayList<Obra> listaObrasEliminadas = new ArrayList<>();
        ControlGaleria controlGaleria = new ControlGaleria(listaArtistas,listaArtistasEliminados,listaCompras);
        ControlCliente controlCliente = new ControlCliente(listaClientes,listaClientesEliminados);
        GestionObras gestionObras = new GestionObras(listaObras,listaObrasEliminadas);

        Scanner scanner = new Scanner(System.in);
        int opcion;


        do {
            System.out.println("ingrese la opcion que desee");
            System.out.println("1. Agregar obras");
            System.out.println("2. Agregar cliente");
            System.out.println("3. Agregar artista");
            System.out.println("4. Eliminar obras");
            System.out.println("5. Eliminar cliente");
            System.out.println("6. Eliminar artista");
            System.out.println("7. Listar obras");
            System.out.println("8. Listar cliente");
            System.out.println("9. Listar artista");
            System.out.println("10. Realizar compra");
            System.out.println("11. Listar compra");
            System.out.println("12.Salir");
            System.out.println("Opcion: ");
            opcion = scanner.nextInt();


            switch (opcion) {
                case 1 -> gestionObras.agregarObra(listaObras,listaArtistas);
                case 2 -> controlCliente.agregarCliente(listaClientes);
                case 3 -> controlGaleria.agregarArtista(listaArtistas);
                case 4 -> gestionObras.eliminarObra(listaObras,listaObrasEliminadas);
                case 5 -> controlCliente.eliminarCliente(listaClientes,listaClientesEliminados);
                case 6 -> controlGaleria.eliminarArtista(listaArtistas,listaArtistasEliminados);
                case 7 -> gestionObras.listarObra(listaObras);
                case 8 -> controlCliente.listarCliennte(listaClientes);
                case 9 -> controlGaleria.listarArtista(listaArtistas);
                case 10 -> controlGaleria.realizarCompra(listaCompras, listaObras, listaClientes);
                case 11 -> controlGaleria.listarCompra(listaCompras);
            }
        }
        while (opcion != 12) ;
    }
}
