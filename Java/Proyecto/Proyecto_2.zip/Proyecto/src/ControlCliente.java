import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
public  class ControlCliente {
    private ArrayList<Cliente> clientes;
    private ArrayList<Cliente> clientesEliminados;


    //Constructor
    public ControlCliente(ArrayList<Cliente> clientes, ArrayList<Cliente> clientesEliminados) {
        this.clientes = clientes;
        this.clientesEliminados = clientesEliminados;
    }
    //Getters y Setters
    public ArrayList<Cliente> getCliente() {
        return clientes;
    }
    public void setCliente(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }
    //Metodos de la clase
    public void agregarCliente(ArrayList<Cliente> clientes){

        Scanner scan = new Scanner(System.in);

        System.out.println("Ingrese el nombre del cliente:");
        String nombre = scan.nextLine();
        System.out.println("Ingrese la dirección del cliente");
        String direccion = scan.nextLine();
        System.out.println("Ingrese el correo del cliente");
        String correo = scan.nextLine();

        boolean comprobar;
        comprobar = false;

        for (Cliente c1: clientes) {
            if (c1.getNombre().equals(nombre)) {
                comprobar = true;
                break;
            }
        }
        if (comprobar){
            System.out.println("El cliente ya fue agregado.");
        }else{
            Cliente clienteAux = new Cliente(nombre,direccion,correo);
            clientes.add(clienteAux);
        }

    }
    public void eliminarCliente(ArrayList<Cliente> clientes,ArrayList<Cliente> clientesEliminados) {
        /*
        Scanner scan = new Scanner(System.in);

        System.out.println("Ingrese el correo del cliente que desea eliminar:");
        String correo = scan.nextLine();

        boolean comprobar = false;
        for (Cliente c1: clientes) {
            if (c1.getCorreo().equals(correo)) {
                clientes.remove(c1);
                clientesEliminados.add(c1);
                comprobar = true;
                break;
            }
        }
        if (comprobar){
            System.out.println("No se encontro ningun cliente con ese correo, intente de nuevo");
        }else{
            System.out.println("El cliente se elimino correctamente");
        }
        */
        Scanner scan = new Scanner(System.in);

        System.out.println("Ingrese el correo del cliente que desea eliminar:");
        String correo = scan.nextLine();

        boolean clienteEncontrado = false;

        Iterator<Cliente> iterator = clientes.iterator();
        while (iterator.hasNext()) {
            Cliente cliente = iterator.next();
            if (cliente.getCorreo().equals(correo)) {
                iterator.remove();
                clientesEliminados.add(cliente);
                clienteEncontrado = true;
                break;
            }
        }

        if (clienteEncontrado) {
            System.out.println("El cliente se eliminó correctamente.");
        } else {
            System.out.println("No se encontró ningún cliente con ese correo.");
        }

    }
    public void listarCliennte(ArrayList<Cliente> clientes){
        if(clientes.isEmpty()){
            System.out.println("Aun no hay clientes resgistrados");
        }else{
            System.out.println("->LISTA DE CLIENTES: ");
            for (Cliente c1: clientes){
                c1.presentarCliente();
            }
        }
    }


}

