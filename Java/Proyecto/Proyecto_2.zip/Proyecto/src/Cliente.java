import java.sql.SQLOutput;

public class Cliente {
    private String nombre;
    private String direccion;
    private String correo;
    //Constructor
    public Cliente (String name){}
    public Cliente( String nombre, String direccion, String correo) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.correo = correo;
    }
    //Getters & setters
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    //Methods
    public void presentarCliente(){
        System.out.println("->LISTA DE CLIENTES:");
        System.out.println("->NOMBRE: "+getNombre());
        System.out.println("->DIRECCION: "+getDireccion());
        System.out.println("->CORREO: "+getCorreo());
        System.out.println("--------------------------------------------------------");
    }

}