import java.time.LocalDate;
public class Compra {
    private LocalDate fecha;
    private Cliente cliente;
    private double precio;
    private Obra obra;

    //Constructor
    public Compra( LocalDate fecha, Cliente cliente, double precio, Obra obra) {
        this.fecha = fecha;
        this.cliente = cliente;
        this.precio = precio;
        this.obra = obra;
    }

    //Getters & Setters
    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Obra getObra() {
        return obra;
    }

    public void setObra(Obra obra) {
        this.obra = obra;
    }

    // Methods
    public void presentarCompra() {
        System.out.println("FECHA: " + getFecha());
        System.out.println("PRECIO: " + getObra().getPrecio());
        System.out.println("CLIENTE: " + getCliente().getNombre());
        System.out.println("OBRA: " + getObra().getTitulo());
    }
}

