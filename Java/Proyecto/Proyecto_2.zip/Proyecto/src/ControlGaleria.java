import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
class ControlGaleria{
    private ArrayList <Artista> Artistas;
    private ArrayList <Artista> ArtistasEliminados;
    private ArrayList <Compra> Compras;

    public ControlGaleria(ArrayList<Artista> artistas, ArrayList<Artista> artistasEliminados, ArrayList<Compra> compras) {
        this.Artistas = artistas;
        this.ArtistasEliminados = artistasEliminados;
        this.Compras = compras;
    }

    //Constructor
    public void setArtistas(ArrayList<Artista> artista) {
        this.Artistas = artista;
    }
    public ArrayList<Artista> getArtistas() {
        return Artistas;
    }
    public void setCompras(ArrayList<Compra> compras) {
        this.Compras = compras;
    }
    public ArrayList<Compra> getCompras() {
        return Compras;
    }
    public ArrayList<Artista> getArtistasEliminados() {
        return ArtistasEliminados;
    }
    public void setArtistasEliminados(ArrayList<Artista> artistasEliminados) {
        this.ArtistasEliminados = artistasEliminados;
    }
    //Methods
    public void agregarArtista(ArrayList<Artista> Artistas){
        Scanner scan = new Scanner(System.in);
        boolean comprobarIdRepetido=false;

        System.out.println("Ingrese el id del artista");
        int id = scan.nextInt();

        for(Artista ArtistaAux: Artistas){
            if (ArtistaAux.getId() == id) {
                comprobarIdRepetido = true;
                break;
            }
        }
        if (!comprobarIdRepetido){
            scan.nextLine();
            System.out.println("Ingrese el nombre del artista");
            String nombre = scan.nextLine();
            System.out.println("Ingrese la fecha de nacimiento del artista");
            String fechaNacimineto = scan.nextLine();
            System.out.println("Ingrese la nacionalidad del artista");
            String nacionalidad = scan.nextLine();
            scan.nextLine();
            System.out.println("Ingrese la biografia del artista");
            String biografia = scan.nextLine();
            Artista ArtistaNuevo = new Artista(id,nombre,fechaNacimineto,nacionalidad,biografia);
            Artistas.add(ArtistaNuevo);
        }else {
            System.out.println("El artista ya fue registrado");
        }
    }
    public void eliminarArtista(ArrayList<Artista> Artistas,ArrayList<Artista> ArtistasEliminados){
        /*
        Scanner scan = new Scanner(System.in);
        System.out.println("Igrese el ID del artista a eliminar");
        int id = scan.nextInt();
        for (Artista ArtistaAux: Artistas) {
            if (ArtistaAux.getId() == id ){
                Artistas.remove(ArtistaAux);
                System.out.println("Se elimino el artista correctamente");
                ArtistasEliminados.add(ArtistaAux);
            }
        }
        */
        Scanner scan = new Scanner(System.in);
        System.out.println("Ingrese el ID del artista a eliminar:");
        int id = scan.nextInt();
        boolean artistaEncontrado = false;

        Iterator<Artista> iterator = Artistas.iterator();
        while (iterator.hasNext()) {
            Artista artista = iterator.next();
            if (artista.getId() == id) {
                iterator.remove();
                artistaEncontrado = true;
                ArtistasEliminados.add(artista);
                break;
            }
        }

        if (artistaEncontrado) {
            System.out.println("Se eliminó el artista correctamente.");
        } else {
            System.out.println("No se encontró el artista con el ID especificado.");
        }

    }
    public void listarArtista(ArrayList<Artista> Artistas){
        if(Artistas.isEmpty()){
            System.out.println("No hay Artistas registrados aun");
        }else {
            for (Artista ArtistaAux: Artistas) {
                ArtistaAux.presentarArtista();
            }
        }

    }
    public void realizarCompra(ArrayList<Compra> Compras,ArrayList <Obra> obras, ArrayList<Cliente>Clientes) {

        Scanner scanner = new Scanner(System.in);
        int indiceObra = 0;
        Obra obraComprar = null;
        int comprobar = 0;
        int confirmacion = 0;
        boolean comprobarcliente = false;
        Cliente clienteCompra = null;
        double precioObra = 0;

        System.out.println("Presiona Enter para mostrar la siguiente obra (Escribe 'c' para comprar una obra)");
        System.out.println("Escribe fin para dejar de ver las obras");
        System.out.println("-> OBRAS QUE PUEDE COMPRAR:");

        while (true) {
            String tecla = scanner.nextLine();

            if (tecla.equals("fin")) {
                // Si se ingresa "fin", se termina la ejecución
                break;
            } else if (tecla.equals("c")) {
                // Si se ingresa "c", se guarda la obra y se termina el ciclo
                obraComprar = obras.get(indiceObra-1);
                precioObra = obraComprar.getPrecio();
                comprobar = 1;
                break;
            }

            if (indiceObra < obras.size()) {
                Obra obraItaradora = obras.get(indiceObra);
                obraItaradora.presentarObra();
                indiceObra++;
            } else {
                System.out.println("Ya se han mostrado todas las obras.");
                break;
            }
        }

        if (comprobar == 1) {
            System.out.println("Has seleccionado la obra: " +obraComprar.getTitulo()+" con un valor de: "+obraComprar.getPrecio());
        }

        System.out.println("Ingrese su nombre (de cliente):");
        String nombre = scanner.nextLine();

        for (Cliente c1: Clientes){
            if (c1.getNombre().equals(nombre)) {
                System.out.println("Esta seguro que desea compra estas obra?");
                System.out.println("1 -> Si");
                System.out.println("2 -> No");
                confirmacion = scanner.nextInt();
                comprobarcliente = true;
                clienteCompra = c1;
                break;
            }
        }
        if (comprobarcliente && confirmacion == 1){
            Compra compraNueva = new Compra(LocalDate.now(),clienteCompra,precioObra,obraComprar);
            Compras.add(compraNueva);
            System.out.println("La compra fue exitosa!");
            obras.remove(obraComprar);
        }else {
            System.out.println("Se cancelo la compra, intentelo de nuevo");
        }
    }
    public void listarCompra(ArrayList<Compra> Compras){
        if (Compras.isEmpty()){
            System.out.println("No se han registrado compras.");
        }else{
            System.out.println("-> LISTA DE COMPRAS: ");
            for (Compra compraAux: Compras){
                compraAux.presentarCompra();
            }
        }
    }

}
