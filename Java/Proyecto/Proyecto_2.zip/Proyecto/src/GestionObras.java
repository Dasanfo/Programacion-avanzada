import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.Scanner;

public  class GestionObras {
    private ArrayList <Obra> obras;
    private ArrayList <Obra> obrasEliminadas;

    //Constructor
    public GestionObras(){}
    public GestionObras(ArrayList<Obra> obras,ArrayList <Obra> obrasEliminadas) {
        this.obras = obras;
        this.obrasEliminadas = obrasEliminadas;
    }
    //Getters y Setters
    public ArrayList<Obra> getObras() {
        return obras;
    }
    public void setObras(ArrayList<Obra> obras) {
        this.obras = obras;
    }
    public ArrayList<Obra> getObrasEliminadas() {
        return obras;
    }
    public void setObrasEliminadas(ArrayList<Obra> obrasEliminadas) {
        this.obrasEliminadas = obrasEliminadas;
    }
    //Metodos

    public void agregarObra(ArrayList <Obra> obras, ArrayList <Artista> Artistas){
        Scanner scan = new Scanner(System.in);
        boolean comprobarListaobraVacia,comprobarNombreArtistaRepetido,comprobartitulorepetido;
        comprobarListaobraVacia = false;
        comprobarNombreArtistaRepetido = false;
        comprobartitulorepetido = false;
        Artista artistaObra = null;

        System.out.println("Ingrese el nombre del artista de la obra:");
        String artista = scan.nextLine();
        System.out.println("Ingrese el titulo de la obra:");
        String titulo = scan.nextLine();

        if(obras.isEmpty()){
            comprobarListaobraVacia = true;
            for(Artista artista1: Artistas){
                if(artista1.getNombre().equals(artista)){
                    comprobarNombreArtistaRepetido = true; // nesecito asegurarme que el artista ya fue creado
                    System.out.println("Ingrese la tecnica de la obra:");
                    String tecnica = scan.nextLine();
                    System.out.println("Ingrese el año de la obra:");
                    int anioCreacion = scan.nextInt();
                    System.out.println("Ingrese el precio de la obra:");
                    double precio = scan.nextDouble();
                    Obra obraNueva = new Obra(titulo,tecnica,anioCreacion,precio,artista1);
                    obras.add(obraNueva);
                }
            }
            if(!comprobarNombreArtistaRepetido){
                System.out.println("No se encontro el artista, porfavor agregar el artista antes de agregar la obra");
            }
        }
        if (!comprobarListaobraVacia){
            for (Artista artista1: Artistas){
                if (artista1.getNombre().equals(artista)) {
                    comprobarNombreArtistaRepetido = true; // nesecito comprar que el artista ya fue creado
                    artistaObra = artista1;
                    for (Obra obra01: obras){
                        if (obra01.getTitulo().equals(titulo)) {
                            System.out.println("El titulo ya esta en la lista");
                            comprobartitulorepetido = true;
                            break;
                        }
                    }
                }
            }
            if(comprobartitulorepetido == false  && comprobarNombreArtistaRepetido == true){
                System.out.println("Ingrese la tecnica de la obra:");
                String tecnica = scan.nextLine();
                System.out.println("Ingrese el año de la obra:");
                int anioCreacion = scan.nextInt();
                System.out.println("Ingrese el precio de la obra:");
                double precio = scan.nextDouble();
                Obra obraNueva = new Obra(titulo,tecnica,anioCreacion,precio,artistaObra);
                obras.add(obraNueva);
            }
            if(comprobarNombreArtistaRepetido == false){
                System.out.println("No se encontro el artista, porfavor agregar el artista primero");
            }
            if(comprobartitulorepetido == true){
                System.out.println("El titulo ingresado ya esta en la lista de obras.");
            }
        }

    }
    public void eliminarObra(ArrayList <Obra> obras,ArrayList <Obra> obrasEliminadas) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Ingrese el título de la obra a eliminar: ");
        String titulo = scan.nextLine();
        boolean obraEncontrada = false;

        Iterator<Obra> iterator = obras.iterator();
        while (iterator.hasNext()) {
            Obra obra = iterator.next();
            if (obra.getTitulo().equals(titulo)) {
                iterator.remove();
                obrasEliminadas.add(obra);
                obraEncontrada = true;
                break;
            }
        }

        if (obraEncontrada) {
            System.out.println("La obra \"" + titulo + "\" se ha eliminado correctamente.");
        } else {
            System.out.println("No se encontró la obra \"" + titulo + "\" en la lista de obras.");
        }
    }
    public void listarObra(ArrayList <Obra> obras){
        if(obras.isEmpty()){
            System.out.println("Aun no hay lista respistradas");
        }else{
            System.out.println("LISTA DE OBRAS: ");
            for (Obra obraAux: obras){
                obraAux.presentarObra();
            }
        }
    }
}
