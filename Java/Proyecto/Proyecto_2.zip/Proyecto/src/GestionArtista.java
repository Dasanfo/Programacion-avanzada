import java.util.ArrayList;
public class GestionArtista {
    private ArrayList <Artista> Artistas;
    //Constructor
    public GestionArtista(ArrayList<Artista> artistas) {
        Artistas = artistas;
    }
    public void agragarArtista(int id, String nombre, String fechaNacimineto, String nacionalidad, String biografia){
        Artista artistaAux = new Artista(id, nombre, fechaNacimineto, nacionalidad, biografia);
        Artistas.add(artistaAux);
    }

    public void eliminarArtista(int id){
        for (Artista artistaAux: Artistas){
            if (artistaAux.getId() == id){
                Artistas.remove(artistaAux);
            }
        }
    }

    public void listarArtistas(){
        for (Artista artistaAux: Artistas){
            artistaAux.presentarArtista();
        }
    }
}