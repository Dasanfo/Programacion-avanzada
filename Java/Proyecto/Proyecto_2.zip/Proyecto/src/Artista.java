import java.sql.SQLOutput;

public class Artista {
    private int id;
    private String nombre;
    private String fechaNacimineto;
    private String nacionalidad;
    private String biografia;
    //Constructor
    public Artista(int id, String nombre, String fechaNacimineto, String nacionalidad, String biografia) {
        this.id = id;
        this.nombre = nombre;
        this.fechaNacimineto = fechaNacimineto;
        this.nacionalidad = nacionalidad;
        this.biografia = biografia;
    }
    //Setter & Getters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getFechaNacimineto() {
        return fechaNacimineto;
    }
    public void setFechaNacimineto(String fechaNacimineto) {
        this.fechaNacimineto = fechaNacimineto;
    }
    public String getNacionalidad() {
        return nacionalidad;
    }
    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }
    public String getBiografia() {
        return biografia;
    }
    public void setBiografia(String biografia) {
        this.biografia = biografia;
    }
    //Methods
    public void presentarArtista(){
        System.out.println("-> LISTA DE ARTISTAS");
        System.out.println("->ID: "+getId());
        System.out.println("->NOMBRE: "+getNombre());
        System.out.println("->FECHA DE NACIMINETO: "+getFechaNacimineto());
        System.out.println("->NACIONALIDAD: "+getNacionalidad());
        System.out.println("->BIOGRAFIA: "+getBiografia());
        System.out.println("--------------------------------------------------------");
    }
}
